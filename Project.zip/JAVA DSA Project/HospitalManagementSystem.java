import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

public class HospitalManagementSystem {
    private static Scanner sc = new Scanner(System.in);
    private static Hospital hospital = new Hospital();
    private static AuthenticationSystem authSystem = AuthenticationSystem.loadData();

    public static void main(String[] args) {
        if (!loginMenu()) {
            System.out.println("Login failed. Exiting system...");
            return;
        }

        hospital.loadData();
        showMainMenu();

    }

    private static void listUsers() {
        authSystem.printAllUsers();
    }
private static boolean loginMenu() {
    while (true) {
        System.out.println("\n=== Hospital Management System Login ===");
        System.out.println("1. Login");
        System.out.println("2. Exit");
        System.out.print("Enter choice: ");

        int choice = -1;
        try {
            choice = Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input! Please enter a number.");
            continue;
        }

        switch (choice) {
            case 1:
                System.out.print("Username: ");
                String username = sc.nextLine();
                System.out.print("Password: ");
                String password = sc.nextLine();

                if (authSystem.login(username, password)) {
                    System.out.println("Login successful! Welcome, " + username);
                    return true;
                } else {
                    System.out.println("Invalid username or password!");
                }
                break;

            case 2:
                return false;

            default:
                System.out.println("Invalid choice! Please enter 1 or 2.");
        }
    }
}


    private static void showMainMenu() {
        while (true) {
            System.out.println("\n=== Hospital Management System ===");
            System.out.println("Logged in as: " + authSystem.getCurrentUser().getUsername());
            System.out.println("1. Patient Management");
            System.out.println("2. Doctor Management");
            System.out.println("3. Appointments");
            System.out.println("4. Ward Management");
            System.out.println("5. Billing System");
            System.out.println("6. Prescription Management");

            if (authSystem.getCurrentUser().getType() == UserType.ADMIN) {
                System.out.println("7. Emergency Services");
                System.out.println("8. Reports & Statistics");
                System.out.println("9. User Management");
                System.out.println("10. Save & Exit");
            } else {
                System.out.println("7. Save & Exit");
            }

            System.out.print("Enter choice: ");

            int maxChoice = authSystem.getCurrentUser().getType() == UserType.ADMIN ? 11 : 7;
            int choice = -1;
            while (choice < 1 || choice > maxChoice) {
                try {
                    choice = sc.nextInt();
                    if (choice < 1 || choice > maxChoice) {
                        System.out.println("Invalid choice! Please enter a number between 1 and " + maxChoice);
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input! Please enter a valid number.");
                    sc.nextLine();
                }
            }

            sc.nextLine();
            switch (choice) {
                case 1:
                    patientManagement();
                    break;
                case 2:
                    doctorManagement();
                    break;
                case 3:
                    appointmentSystem();
                    break;
                case 4:
                    wardManagement();
                    break;
                case 5:
                    billingSystem();
                    break;
                case 6:
                    prescriptionManagement();
                    break;
                case 7:
                    if (authSystem.getCurrentUser().getType() == UserType.ADMIN) {
                        emergencySystem();
                    } else {
                        saveAndExit();
                    }
                    break;
                case 8:
                    if (authSystem.getCurrentUser().getType() == UserType.ADMIN) {
                        reportsSystem();
                    }
                    break;
                case 9:
                    if (authSystem.getCurrentUser().getType() == UserType.ADMIN) {
                        userManagement();
                    }
                    break;
                case 10:
                    if (authSystem.getCurrentUser().getType() == UserType.ADMIN) {
                        saveAndExit();
                    }
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    private static void saveAndExit() {
        hospital.saveData();
        authSystem.saveData();
        System.out.println("Exiting system...");
        System.exit(0);
    }

    private static void userManagement() {
        if (authSystem.getCurrentUser().getType() != UserType.ADMIN) {
            System.out.println("Access denied! Only admins can manage users.");
            return;
        }

        while (true) {
            System.out.println("\n--- User Management ---");
            System.out.println("1. Add User");
            System.out.println("2. List Users");
            System.out.println("3. Delete User");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter username: ");
                    String username = sc.nextLine();
                    System.out.print("Enter password: ");
                    String password = sc.nextLine();
                    System.out.print("Enter user type (1=ADMIN, 2=STAFF): ");
                    int type = sc.nextInt();
                    sc.nextLine();

                    boolean success = authSystem.addUser(username, password,
                            type == 1 ? UserType.ADMIN : UserType.STAFF);
                    if (success) {
                        System.out.println("User added successfully!");
                    } else {
                        System.out.println("Username already exists!");
                    }
                    break;
                case 2:
                    listUsers();
                    break;
                case 3:
                    deleteUser();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    private static void deleteUser() {
        System.out.print("Enter username to delete: ");
        String username = sc.nextLine();

        if (username.equals(authSystem.getCurrentUser().getUsername())) {
            System.out.println("Cannot delete currently logged in user!");
            return;
        }

        boolean success = authSystem.removeUser(username);
        if (success) {
            System.out.println("User '" + username + "' deleted successfully.");
        } else {
            if (username.equals("admin")) {
                System.out.println("Cannot delete default admin account!");
            } else {
                System.out.println("User not found or could not be deleted!");
            }
        }
    }

    private static void wardManagement() {
        while (true) {
            System.out.println("\n--- Ward Management ---");
            System.out.println("1. Add Ward");
            System.out.println("2. View Wards");
            System.out.println("3. Assign Patient to Ward");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); 
            switch (choice) {
                case 1:
                    System.out.print("Enter Ward Number: ");
                    int wardNum = sc.nextInt();
                    System.out.print("Enter Total Beds: ");
                    int beds = sc.nextInt();
                    hospital.addWard(new Ward(wardNum, beds));
                    System.out.println("Ward added.");
                    break;
                case 2:
                    hospital.viewWards();
                    break;
                case 3:
                    if (hospital.getPatientsCount() == 0) {
                        System.out.println("No patients available. Please add patients first.");
                        break;
                    }
                    if (hospital.getWardsCount() == 0) {
                        System.out.println("No wards available. Please add wards first.");
                        break;
                    }
                    System.out.print("Enter Patient ID: ");
                    int patientId = sc.nextInt();
                    System.out.print("Enter Ward Number: ");
                    int wNumber = sc.nextInt();
                    boolean assigned = hospital.assignPatientToWard(patientId, wNumber);
                    if (!assigned) {
                        System.out.println("Could not assign patient to ward.");
                    }
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void patientManagement() {
        while (true) {
            System.out.println("\n--- Patient Management ---");
            System.out.println("1. Add Patient");
            System.out.println("2. View All Patients");
            System.out.println("3. View Patients Sorted by Name");
            System.out.println("4. Search Patient by ID");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter Patient Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Age: ");
                    int age = sc.nextInt();
                    Patient p = new Patient(hospital.getNextPatientId(), name, age);
                    hospital.addPatient(p);
                    System.out.println("Patient added with ID: " + p.getId());
                    break;
                case 2:
                    hospital.viewPatients();
                    break;
                case 3:
                    hospital.viewPatientsSortedByName();
                    break;
                case 4:
                    System.out.print("Enter Patient ID to search: ");
                    int searchId = sc.nextInt();
                    Patient foundPatient = hospital.searchPatientById(searchId);
                    if (foundPatient != null) {
                        System.out.println("Patient found: " + foundPatient);
                    } else {
                        System.out.println("Patient with ID " + searchId + " not found.");
                    }
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    private static void doctorManagement() {
        while (true) {
            System.out.println("\n--- Doctor Management ---");
            System.out.println("1. Add Doctor");
            System.out.println("2. View All Doctors");
            System.out.println("3. View Doctors Sorted by Name");
            System.out.println("4. Search Doctor by ID");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter Doctor Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Specialization: ");
                    String spec = sc.nextLine();
                    Doctor d = new Doctor(hospital.getNextDoctorId(), name, spec);
                    hospital.addDoctor(d);
                    System.out.println("Doctor added with ID: " + d.getId());
                    break;
                case 2:
                    hospital.viewDoctors();
                    break;
                case 3:
                    hospital.viewDoctorsSortedByName();
                    break;
                case 4:
                    System.out.print("Enter Doctor ID to search: ");
                    int searchId = sc.nextInt();
                    Doctor foundDoctor = hospital.searchDoctorById(searchId);
                    if (foundDoctor != null) {
                        System.out.println("Doctor found: " + foundDoctor);
                    } else {
                        System.out.println("Doctor with ID " + searchId + " not found.");
                    }
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    private static void appointmentSystem() {
    while (true) {
        System.out.println("\n--- Appointment System ---");
        System.out.println("1. Schedule Appointment");
        System.out.println("2. View Appointments");
        System.out.println("3. Back to Main Menu");
        System.out.print("Enter choice: ");
        
        int choice = sc.nextInt();
        sc.nextLine();

        switch (choice) {
            case 1:
                if (hospital.getDoctorsCount() == 0) {
                    System.out.println("No doctors available. Please add doctors first.");
                    return;
                }
                if (hospital.getPatientsCount() == 0) {
                    System.out.println("No patients available. Please add patients first.");
                    return;
                }

                System.out.print("Enter Patient ID: ");
                int pid = sc.nextInt();
                System.out.print("Enter Doctor ID: ");
                int did = sc.nextInt();
                hospital.scheduleAppointment(pid, did);
                break;
            case 2:
                hospital.viewAppointments();
                break;
            case 3:
                return;
            default:
                System.out.println("Invalid choice!");
        }
    }
}


    private static void billingSystem() {
    System.out.print("Enter Patient ID: ");
    int pid = sc.nextInt();

    System.out.print("Enter Bill Amount: ");
    double amt = sc.nextDouble();

    if (amt <= 0) {
        System.out.println("Error: Bill amount must be greater than zero.");
        return; 
    }

    System.out.print("Enter Bill Type (1=CONSULTATION, 2=MEDICATION, 3=ROOM_CHARGES, 4=PROCEDURE): ");
    int typeIndex = sc.nextInt();
    sc.nextLine();

    
    if (typeIndex < 1 || typeIndex > BillType.values().length) {
        System.out.println("Error: Invalid bill type.");
        return;
    }

    BillType type = BillType.values()[typeIndex - 1];
    hospital.generateBill(pid, type, amt);
}


    private static void prescriptionManagement() {
        System.out.print("Enter Patient ID: ");
        int pid = sc.nextInt();
        System.out.print("Enter Doctor ID: ");
        int did = sc.nextInt();
        sc.nextLine(); 
        System.out.print("Enter Medication: ");
        String med = sc.nextLine();
        System.out.print("Enter Dosage: ");
        String dosage = sc.nextLine();
        hospital.addPrescription(pid, did, med, dosage);
    }

    private static void emergencySystem() {
        System.out.print("Enter Patient ID: ");
        int pid = sc.nextInt();
        System.out.println("Select Emergency Level: 1. CRITICAL 2. URGENT 3. STABLE");
        int level = sc.nextInt();
        sc.nextLine(); 
        EmergencyLevel lvl = EmergencyLevel.values()[level - 1];
        hospital.addEmergencyCase(pid, lvl);
    }

    private static void reportsSystem() {
        hospital.showReports();
    }
}


class Hospital implements Serializable {
    private static final long serialVersionUID = 1L;
    private LinkedList<Patient> patients = new LinkedList<>();
    private LinkedList<Doctor> doctors = new LinkedList<>();
    private List<Appointment> appointments = new ArrayList<>();
    private BinarySearchTree<Patient> bstPatients = new BinarySearchTree<>();
    private BinarySearchTree<Doctor> bstDoctors = new BinarySearchTree<>();
    private BinarySearchTree<Bill> bstBills = new BinarySearchTree<>();
    private Map<Integer, Ward> wards = new HashMap<>();
    private List<Prescription> prescriptions = new ArrayList<>();
    private PriorityQueue<EmergencyCase> emergencyQueue = new PriorityQueue<>();
    private int lastPatientId = 0;
    private int lastDoctorId = 0;
    private int lastBillId = 0;

    public int getNextPatientId() {
        return ++lastPatientId;
    }

    public int getNextDoctorId() {
        return ++lastDoctorId;
    }

    public int getNextBillId() {
        return ++lastBillId;
    }

    public int getDoctorsCount() {
        return doctors.size();
    }

    public int getPatientsCount() {
        return patients.size();
    }

    public int getWardsCount() {
        return wards.size();
    }

    public void viewPatients() {
        if (patients.isEmpty()) {
            System.out.println("No patients available.");
        } else {
            System.out.println("=== List of Patients ===");
            for (Patient patient : patients) {
                System.out.println(patient);
            }
        }
    }

    public void viewAppointments() {
    if (appointments.isEmpty()) {
        System.out.println("No appointments found.");
        return;
    }

    System.out.println("=== Appointments List ===");
    for (Appointment appt : appointments) {
        System.out.println(appt);
    }
}


    public void viewPatientsSortedByName() {
        if (patients.isEmpty()) {
            System.out.println("No patients available.");
        } else {
            System.out.println("=== Patients Sorted by Name ===");
            List<Patient> sortedPatients = new ArrayList<>(patients);
            mergeSortPatientsByName(sortedPatients, 0, sortedPatients.size() - 1);
            sortedPatients.forEach(System.out::println);
        }
    }


    public Patient searchPatientById(int id) {
        Patient searchKey = new Patient(id, "", 0);
        Patient found = bstPatients.search(searchKey);

        if (found != null) {
            return found;
        }

        System.out.println("BST search failed, falling back to linear search...");
        return linearSearchPatient(id);
    }

    private Patient linearSearchPatient(int id) {
        for (Patient patient : patients) {
            if (patient.getId() == id) {
                return patient;
            }
        }
        return null;
    }

    public Doctor searchDoctorById(int id) {
        Doctor searchKey = new Doctor(id, "", "");
        Doctor found = bstDoctors.search(searchKey);

        if (found != null) {
            return found;
        }

        System.out.println("BST search failed, falling back to linear search...");
        return linearSearchDoctor(id);
    }

    
    private Doctor linearSearchDoctor(int id) {
        for (Doctor doctor : doctors) {
            if (doctor.getId() == id) {
                return doctor;
            }
        }
        return null;
    }

    private void mergeSortPatientsByName(List<Patient> patients, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;
            mergeSortPatientsByName(patients, left, mid);
            mergeSortPatientsByName(patients, mid + 1, right);
            mergePatientsByName(patients, left, mid, right);
        }
    }

    private void mergePatientsByName(List<Patient> patients, int left, int mid, int right) {
        List<Patient> temp = new ArrayList<>(right - left + 1);
        int i = left, j = mid + 1;

        while (i <= mid && j <= right) {
            if (patients.get(i).getName().compareTo(patients.get(j).getName()) <= 0) {
                temp.add(patients.get(i++));
            } else {
                temp.add(patients.get(j++));
            }
        }

        while (i <= mid) {
            temp.add(patients.get(i++));
        }

        while (j <= right) {
            temp.add(patients.get(j++));
        }

        for (int k = 0; k < temp.size(); k++) {
            patients.set(left + k, temp.get(k));
        }
    }

    public void viewDoctorsSortedByName() {
        if (doctors.isEmpty()) {
            System.out.println("No doctors available.");
        } else {
            System.out.println("=== Doctors Sorted by Name ===");
            List<Doctor> sortedDoctors = new ArrayList<>(doctors);
            mergeSortDoctorsByName(sortedDoctors, 0, sortedDoctors.size() - 1);
            sortedDoctors.forEach(System.out::println);
        }
    }

    private void mergeSortDoctorsByName(List<Doctor> doctors, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;
            mergeSortDoctorsByName(doctors, left, mid);
            mergeSortDoctorsByName(doctors, mid + 1, right);
            mergeDoctorsByName(doctors, left, mid, right);
        }
    }

    private void mergeDoctorsByName(List<Doctor> doctors, int left, int mid, int right) {
        List<Doctor> temp = new ArrayList<>(right - left + 1);
        int i = left, j = mid + 1;

        while (i <= mid && j <= right) {
            if (doctors.get(i).getName().compareTo(doctors.get(j).getName()) <= 0) {
                temp.add(doctors.get(i++));
            } else {
                temp.add(doctors.get(j++));
            }
        }

        while (i <= mid) {
            temp.add(doctors.get(i++));
        }

        while (j <= right) {
            temp.add(doctors.get(j++));
        }

        for (int k = 0; k < temp.size(); k++) {
            doctors.set(left + k, temp.get(k));
        }
    }

    public void viewPatientsSortedById() {
        if (patients.isEmpty()) {
            System.out.println("No patients available.");
        } else {
            System.out.println("=== Patients Sorted by ID ===");
            List<Patient> sortedPatients = new ArrayList<>(patients);
            mergeSortPatientsById(sortedPatients, 0, sortedPatients.size() - 1);
            sortedPatients.forEach(System.out::println);
        }
    }

    private void mergeSortPatientsById(List<Patient> patients, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;
            mergeSortPatientsById(patients, left, mid);
            mergeSortPatientsById(patients, mid + 1, right);
            mergePatientsById(patients, left, mid, right);
        }
    }

    private void mergePatientsById(List<Patient> patients, int left, int mid, int right) {
        List<Patient> temp = new ArrayList<>(right - left + 1);
        int i = left, j = mid + 1;

        while (i <= mid && j <= right) {
            if (patients.get(i).getId() <= patients.get(j).getId()) {
                temp.add(patients.get(i++));
            } else {
                temp.add(patients.get(j++));
            }
        }

        while (i <= mid) {
            temp.add(patients.get(i++));
        }

        while (j <= right) {
            temp.add(patients.get(j++));
        }

        for (int k = 0; k < temp.size(); k++) {
            patients.set(left + k, temp.get(k));
        }
    }

    public void viewDoctorsSortedById() {
        if (doctors.isEmpty()) {
            System.out.println("No doctors available.");
        } else {
            System.out.println("=== Doctors Sorted by ID ===");
            List<Doctor> sortedDoctors = new ArrayList<>(doctors);
            mergeSortDoctorsById(sortedDoctors, 0, sortedDoctors.size() - 1);
            sortedDoctors.forEach(System.out::println);
        }
    }

    private void mergeSortDoctorsById(List<Doctor> doctors, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;
            mergeSortDoctorsById(doctors, left, mid);
            mergeSortDoctorsById(doctors, mid + 1, right);
            mergeDoctorsById(doctors, left, mid, right);
        }
    }

    private void mergeDoctorsById(List<Doctor> doctors, int left, int mid, int right) {
        List<Doctor> temp = new ArrayList<>(right - left + 1);
        int i = left, j = mid + 1;

        while (i <= mid && j <= right) {
            if (doctors.get(i).getId() <= doctors.get(j).getId()) {
                temp.add(doctors.get(i++));
            } else {
                temp.add(doctors.get(j++));
            }
        }

        while (i <= mid) {
            temp.add(doctors.get(i++));
        }

        while (j <= right) {
            temp.add(doctors.get(j++));
        }

        for (int k = 0; k < temp.size(); k++) {
            doctors.set(left + k, temp.get(k));
        }
    }

    public void addPatient(Patient patient) {
        patients.add(patient);
        bstPatients.insert(patient);
        Collections.sort(patients, Comparator.comparing(Patient::getName));
    }

    public void addDoctor(Doctor doctor) {
        doctors.add(doctor);
        bstDoctors.insert(doctor);
        Collections.sort(doctors, Comparator.comparing(Doctor::getName));
    }

    public void addWard(Ward ward) {
        wards.put(ward.getWardNumber(), ward);
    }

    public boolean assignPatientToWard(int patientId, int wardNumber) {
        if (wards.isEmpty()) {
            System.out.println("No wards available. Please add wards first.");
            return false;
        }

        Patient patient = bstPatients.search(new Patient(patientId, "", 0));
        if (patient == null) {
            System.out.println("Patient with ID " + patientId + " not found.");
            return false;
        }

        Ward ward = wards.get(wardNumber);
        if (ward == null) {
            System.out.println("Ward with number " + wardNumber + " not found.");
            return false;
        }

        if (ward.getOccupiedBedsCount() >= ward.getTotalBeds()) {
            System.out.println("Ward " + wardNumber + " is full. No available beds.");
            return false;
        }

        ward.occupyBed(patientId);
        System.out.println("Patient " + patient.getName() + " assigned to ward " + wardNumber);
        return true;
    }

    public void viewDoctors() {
        if (doctors.isEmpty()) {
            System.out.println("No doctors available. Please add doctors first.");
        } else {
            System.out.println("=== List of Doctors ===");
            for (Doctor doctor : doctors) {
                System.out.println(doctor);
            }
        }
    }

    public void viewWards() {
        if (wards.isEmpty()) {
            System.out.println("No wards available. Please add wards first.");
        } else {
            System.out.println("=== List of Wards ===");
            for (Ward ward : wards.values()) {
                System.out.println(ward);
            }
        }
    }

    public void scheduleAppointment(int patientId, int doctorId) {
    if (doctors.isEmpty()) {
        System.out.println("No doctors available. Please add doctors first.");
        return;
    }

    Patient patient = bstPatients.search(new Patient(patientId, "", 0));
    Doctor doctor = bstDoctors.search(new Doctor(doctorId, "", ""));

    if (patient == null) {
        System.out.println("Patient with ID " + patientId + " not found.");
    } else if (doctor == null) {
        System.out.println("Doctor with ID " + doctorId + " not found.");
    } else {
        appointments.add(new Appointment(patientId, doctorId));
        System.out.println("Appointment scheduled for patient " + patient.getName() +
                " with doctor " + doctor.getName());
    }
}


    public void generateBill(int patientId, BillType type, double amount) {
        if (patients.isEmpty()) {
            System.out.println("No patients available. Please add patients first.");
            return;
        }

        Patient patient = bstPatients.search(new Patient(patientId, "", 0));
        if (patient == null) {
            System.out.println("Patient with ID " + patientId + " not found.");
            return;
        }

        Bill bill = new Bill(getNextBillId(), patientId, type, amount);
        bstBills.insert(bill);
        patient.addBill(bill.getBillId());
        System.out.println("Bill generated for patient " + patient.getName() + ": " + bill);
    }

    public void addPrescription(int patientId, int doctorId, String medication, String dosage) {
        prescriptions.add(new Prescription(patientId, doctorId, medication, dosage));
        System.out.println("Prescription added.");
    }

    public void addEmergencyCase(int patientId, EmergencyLevel level) {
        emergencyQueue.add(new EmergencyCase(patientId, level));
        System.out.println("Emergency case added with priority: " + level);
    }

    public void showReports() {
        System.out.println("=== Hospital Reports ===");
        System.out.println("Total Patients: " + patients.size());
        System.out.println("Total Doctors: " + doctors.size());
        System.out.println("Total Wards: " + wards.size());
    }

    public void saveData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("hospital.data"))) {
            oos.writeObject(this);
            System.out.println("Data saved successfully.");
        } catch (IOException e) {
            System.err.println("Error saving data: " + e.getMessage());
        }
    }

    public void loadData() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("hospital.data"))) {
            Hospital loaded = (Hospital) ois.readObject();
            this.patients = loaded.patients;
            this.doctors = loaded.doctors;
            this.wards = loaded.wards;
            this.lastPatientId = loaded.lastPatientId;
            this.lastDoctorId = loaded.lastDoctorId;
            this.lastBillId = loaded.lastBillId;
            System.out.println("Data loaded successfully.");
        } catch (FileNotFoundException e) {
            System.out.println("No previous data found. Starting fresh.");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading data: " + e.getMessage());
        }
    }
}

class BinarySearchTree<T extends Comparable<T>> implements Serializable {
    private static final long serialVersionUID = 1L;

    private class Node implements Serializable {
        private static final long serialVersionUID = 1L;
        T data;
        Node left, right;

        Node(T data) {
            this.data = data;
        }
    }

    private Node root;

    public void insert(T data) {
        root = insertRecursive(root, data);
    }

    private Node insertRecursive(Node node, T data) {
        if (node == null) {
            return new Node(data);
        }

        if (data.compareTo(node.data) < 0) {
            node.left = insertRecursive(node.left, data);
        } else if (data.compareTo(node.data) > 0) {
            node.right = insertRecursive(node.right, data);
        }

        return node;
    }

    public T search(T data) {
        return searchRecursive(root, data);
    }

    private T searchRecursive(Node node, T data) {
        if (node == null) {
            return null;
        }

        if (data.compareTo(node.data) == 0) {
            return node.data;
        }

        return data.compareTo(node.data) < 0
                ? searchRecursive(node.left, data)
                : searchRecursive(node.right, data);
    }
}

class Patient implements Serializable, Comparable<Patient> {
    private static final long serialVersionUID = 1L;
    private int id;
    private String name;
    private int age;
    private List<Integer> billIds = new ArrayList<>();

    public Patient(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public void addBill(int billId) {
        billIds.add(billId);
    }

    @Override
    public int compareTo(Patient other) {
        return Integer.compare(this.id, other.id);
    }

    @Override
    public String toString() {
        return "Patient [ID=" + id + ", Name=" + name + ", Age=" + age + "]";
    }
}

class Doctor implements Serializable, Comparable<Doctor> {
    private static final long serialVersionUID = 1L;
    private int id;
    private String name;
    private String specialization;

    public Doctor(int id, String name, String specialization) {
        this.id = id;
        this.name = name;
        this.specialization = specialization;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSpecialization() {
        return specialization;
    }

    @Override
    public int compareTo(Doctor other) {
        return Integer.compare(this.id, other.id);
    }

    @Override
    public String toString() {
        return "Doctor [ID=" + id + ", Name=" + name + ", Specialization=" + specialization + "]";
    }
}

class Appointment implements Serializable {
    private static final long serialVersionUID = 1L;
    private int patientId;
    private int doctorId;
    private LocalDateTime appointmentTime;

    public Appointment(int patientId, int doctorId) {
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.appointmentTime = LocalDateTime.now(); // or let user specify
    }

    @Override
    public String toString() {
        return "Appointment [Patient ID=" + patientId +
               ", Doctor ID=" + doctorId +
               ", Time=" + appointmentTime + "]";
    }
}


class Ward implements Serializable {
    private static final long serialVersionUID = 1L;
    private int wardNumber;
    private int totalBeds;
    private Set<Integer> occupiedBeds = new HashSet<>();

    public Ward(int wardNumber, int totalBeds) {
        this.wardNumber = wardNumber;
        this.totalBeds = totalBeds;
    }

    public int getWardNumber() {
        return wardNumber;
    }

    public int getTotalBeds() {
        return totalBeds;
    }

    public int getOccupiedBedsCount() {
        return occupiedBeds.size();
    }

    public void occupyBed(int patientId) {
        occupiedBeds.add(patientId);
    }

    @Override
    public String toString() {
        return "Ward [Number=" + wardNumber + ", Beds=" + getOccupiedBedsCount() + "/" + totalBeds + "]";
    }
}

class Bill implements Serializable, Comparable<Bill> {
    private static final long serialVersionUID = 1L;
    private int billId;
    private int patientId;
    private BillType type;
    private double amount;
    private boolean paid = false;

    public Bill(int billId, int patientId, BillType type, double amount) {
        this.billId = billId;
        this.patientId = patientId;
        this.type = type;
        this.amount = amount;
    }

    public int getBillId() {
        return billId;
    }

    public int getPatientId() {
        return patientId;
    }

    public BillType getType() {
        return type;
    }

    public double getAmount() {
        return amount;
    }

    public boolean isPaid() {
        return paid;
    }

    @Override
    public int compareTo(Bill other) {
        return Integer.compare(this.billId, other.billId);
    }

    @Override
    public String toString() {
        return "Bill [ID=" + billId + ", Patient=" + patientId + ", Type=" + type +
                ", Amount=" + amount + ", Paid=" + paid + "]";
    }
}

enum BillType {
    CONSULTATION, MEDICATION, ROOM_CHARGES, PROCEDURE
}

class Prescription implements Serializable {
    private static final long serialVersionUID = 1L;
    private int patientId;
    private int doctorId;
    private String medication;
    private String dosage;
    private LocalDate issueDate = LocalDate.now();

    public Prescription(int pid, int did, String med, String dosage) {
        this.patientId = pid;
        this.doctorId = did;
        this.medication = med;
        this.dosage = dosage;
    }

    @Override
    public String toString() {
        return "Prescription [Patient=" + patientId + ", Doctor=" + doctorId +
                ", Medication=" + medication + ", Dosage=" + dosage + ", Date=" + issueDate + "]";
    }
}

class EmergencyCase implements Serializable, Comparable<EmergencyCase> {
    private static final long serialVersionUID = 1L;
    private int patientId;
    private EmergencyLevel level;
    private LocalDateTime time = LocalDateTime.now();

    public EmergencyCase(int pid, EmergencyLevel level) {
        this.patientId = pid;
        this.level = level;
    }

    @Override
    public int compareTo(EmergencyCase o) {
        return Integer.compare(this.level.getPriority(), o.level.getPriority());
    }

    @Override
    public String toString() {
        return "Emergency [Patient=" + patientId + ", Level=" + level + ", Time=" + time + "]";
    }
}

enum EmergencyLevel {
    CRITICAL(1), URGENT(2), STABLE(3);

    private final int priority;

    EmergencyLevel(int p) {
        this.priority = p;
    }

    public int getPriority() {
        return priority;
    }
}

class User implements Serializable {
    private static final long serialVersionUID = 1L;
    private String username;
    private String password;
    private UserType type;

    public User(String username, String password, UserType type) {
        this.username = username;
        this.password = password;
        this.type = type;
    }

    public String getUsername() {
        return username;
    }

    public UserType getType() {
        return type;
    }

    public boolean checkPassword(String password) {
        return this.password.equals(password);
    }
}

enum UserType {
    ADMIN, STAFF
}

class AuthenticationSystem implements Serializable {
    private static final long serialVersionUID = 1L;
    private Map<String, User> users = new HashMap<>();
    private User currentUser = null;

    public boolean removeUser(String username) {
        // Prevent deleting default admin account
        if (username.equals("admin")) {
            return false;
        }

        // Check if user exists
        if (!users.containsKey(username)) {
            return false;
        }

        users.remove(username);
        return true;
    }

    public void printAllUsers() {
        if (users.isEmpty()) {
            System.out.println("No users found.");
            return;
        }

        System.out.println("\n=== List of Users ===");
        System.out.printf("%-15s %-10s%n", "Username", "Type");
        System.out.println("---------------------");
        for (User user : users.values()) {
            System.out.printf("%-15s %-10s%n",
                    user.getUsername(),
                    user.getType().toString());
        }
    }

    public AuthenticationSystem() {
        users.put("admin", new User("admin", "admin123", UserType.ADMIN));
        users.put("staff", new User("staff", "staff123", UserType.STAFF));
    }

    public boolean login(String username, String password) {
        User user = users.get(username);
        if (user != null && user.checkPassword(password)) {
            currentUser = user;
            return true;
        }
        return false;
    }

    public void logout() {
        currentUser = null;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public boolean addUser(String username, String password, UserType type) {
        if (users.containsKey(username)) {
            return false;
        }
        users.put(username, new User(username, password, type));
        return true;
    }

    public void saveData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("auth.data"))) {
            oos.writeObject(this);
        } catch (IOException e) {
            System.err.println("Error saving authentication data: " + e.getMessage());
        }
    }

    public static AuthenticationSystem loadData() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("auth.data"))) {
            return (AuthenticationSystem) ois.readObject();
        } catch (FileNotFoundException e) {
            System.out.println("No previous authentication data found. Creating new system.");
            return new AuthenticationSystem();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading authentication data: " + e.getMessage());
            return new AuthenticationSystem();
        }
    }
}